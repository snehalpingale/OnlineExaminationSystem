<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
?>
<style>
.adminpanel{width: 500px;color: #999;margin: 30px auto 0;padding: 50px;border: 1px solid #ddd;}	

</style>

<div class="main">
<h1>Admin Panel</h1>

<div class="adminpanel">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQvh05DbbPG8ZGnk0maUJMHV_1ZIPKzh2jnMA&usqp=CAU"/>
	<h2>Welcome To Control Admin Panel</h2>
	<p>You can manage your user and online exam system from here....</p>

</div>

	
</div>
<?php include 'inc/footer.php'; ?>