<?php
echo"hello php."
?>